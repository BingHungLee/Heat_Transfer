## updated 0606

-- correction in EDC_cracking
   1. correct the pressure unit
   2. correct the mole fraction(X) to mass fraction(Y)
-- new xml file with aspen parameters and reaction mechanism
-- new model architecture, model.h5, and clf.pickle
-- batch 52, epoch 333

 
## Requirements

conda  env create  --name test -f environment.yml

or

conda create env --name test
conda activate test
pip install -r requirements.txt


## Dependency

elements.xml, chem_annotated.xml, clf.pickle and model.h5 are required by Cantera and Keras. 
Please place it in the same directory before you run it.


## Prediction

This file is the source code of the binary executable ML_model_finalV2.exe.

EDC_cracking() would output compositions and retention time calculated by Cantera to the model.
After that, ML model would do the prediction in predict() and print the cracking rates.

