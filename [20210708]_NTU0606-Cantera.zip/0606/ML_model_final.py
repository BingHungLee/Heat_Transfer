# -*- coding: utf-8 -*-

from os.path import dirname, join
from os import system
import sys
from cantera import add_directory
from pickle import load
from keras.layers import Input, Dense, Activation, concatenate
from keras.models import Model
from keras import losses
from keras import optimizers
from argparse import ArgumentParser
from numpy import zeros, arange, zeros_like, sum, hstack
from cantera import Species, Solution, IdealGasReactor, MassFlowController, Reservoir, SolutionArray, MassFlowController, PressureController, ReactorNet
from silence_tensorflow import silence_tensorflow
silence_tensorflow()
BASE_DIR = dirname(__file__)
if getattr(sys, 'frozen', False):
    BASE_DIR = sys._MEIPASS

else:
    BASE_DIR = dirname(__file__)


def build_model(lr=0.001):
    first_input = Input(shape=(2,), name='Input_layer_1')
    second_input = Input(shape=(31,), name='Input_layer_2')
    third_input = Input(shape=(1,), name='Prev_cracking')

    layer = Dense(13, name='Hinden_layer_1')(first_input)
    layer = Activation('relu')(layer)
    layer = Dense(15, name='Hinden_layer_2')(layer)
    layer = Activation('relu')(layer)
    layer = concatenate([layer, second_input], name='Concatenate_layer')
    layer = Activation('relu')(layer)
    layer = Dense(12, name='Hinden_layer_3')(layer)
    layer = Activation('relu')(layer)
    layer = concatenate([layer, third_input], name='Concatenate_layer_2')
    layer = Dense(1, name='Hinden_layer_4')(layer)
    output = Activation('sigmoid')(layer)

    model = Model(inputs=[first_input, second_input, third_input],
                  outputs=output)
    model.compile(optimizer=optimizers.Adam(lr=lr),
                  loss=losses.mean_absolute_error,
                  metrics=['accuracy', 'mae'])
    return model


def EDC_cracking(
        reaction_mech,
        lst,
        p,
        CCl4,
        mfr,
        n_steps=1000,
        n_pfr=18,
        l=18,
        A=0.03225097679
):
    lst = [i + 273.15 for i in lst]
    p = p * 98066.5 + 101325

    spcs = Species.listFromFile(reaction_mech)
    for spc in spcs[::-1]:
        if spc.composition == {'C': 2.0, 'Cl': 2.0, 'H': 4.0} and spc.charge == 0:
            EDC_l = spc.name
        if spc.composition == {'C': 1.0, 'Cl': 4.0} and spc.charge == 0:
            CCl4_l = spc.name
    EDC = 1 - CCl4
    __compos__ = '{}:{}, {}:{}'.format(
        EDC_l, EDC, CCl4_l, CCl4)
    model = Solution(reaction_mech)
    model.TPY = lst[0], p, __compos__
    r = IdealGasReactor(model)
    r.volume = A * l / n_steps
    up = Reservoir(model, name='up')
    down = Reservoir(model, name='down')
    m = MassFlowController(up, r, mdot=mfr)
    v = PressureController(r, down, master=m, K=1e-5)
    sim = ReactorNet([r])
    z = (arange(n_steps) + 1) * l / n_steps
    __t__ = zeros(n_pfr)
    __compos__ = [None] * n_pfr
    __cracks__ = [0]
    states = SolutionArray(r.thermo)
    for i, T in enumerate(lst[1:]):
        dT = (lst[i+1] - lst[i]) / n_steps
        t_r = zeros_like(z)
        for n in range(n_steps):
            model.TP = lst[i] + (n + 1) * dT, None
            r.syncState()
            model.TPY = r.thermo.TPY
            up.syncState()
            sim.reinitialize()
            sim.set_initial_time(0)
            sim.advance_to_steady_state()
            t_r[n] = r.mass / mfr
            states.append(r.thermo.state)
        __t__[i] = sum(t_r)
        __compos__[i] = model.Y[4:]
        Y = (
            EDC - model.Y[model.species_index(EDC_l)]) / EDC
        __cracks__.append(Y)
    return __compos__, __t__, __cracks__

def predict(reaction_mech, lst, p, CCl4, mfr,
            n_steps, n_pfr, l, A):

    with open(join(BASE_DIR, 'clf.pickle'), 'rb') as f:
        scaler = load(f)
    model = build_model()
    model.load_weights(join(BASE_DIR, 'model.h5'))
    __compos__, __t__, __ = EDC_cracking(reaction_mech,lst,p,CCl4,mfr,n_steps,n_pfr,l,A)
    pre_y = 0
    mfr *= 3.6
    CCl4 *= 1e6
    for i, T in enumerate(lst[1:]):
        t = sum(__t__[:i+1])
        t_r = __t__[i]
        x_pre = hstack([lst[i], lst[i+1], __compos__[i],
                       p, CCl4, t, t_r, pre_y]).reshape(1, -1)
        X_pre = scaler.transform(x_pre[:, :-1])
        pre_y = y = float(model.predict([X_pre[:, 0:2],
                                 X_pre[:, 2:], x_pre[:, -1]]))
        y_pre.append(y)
    print(', '.join([f"{(i * 100):.2f}" for i in y_pre]))


if __name__ == '__main__':
    try:
        mfr = 0.
        p = 0.
        CCl4 = 0.
        lst = []
        while(1):
            print(
                "mass:(T/H) The input should be between 27 and 36 for 20-ton scale and 53 for 30-ton scale")
            mfr = float(sys.stdin.readline())
            if not (27 <= mfr <= 36 or mfr == 53):
                print("mass flow rate out of bound.")
                continue
            print("pressure:(kg/cm2G) The input should be within 10.4 and 14.4.")
            p = float(sys.stdin.readline())
            if p < 10.4 or p > 14.4:
                print("inlet pressure out of bound.")
                continue
            print("CCl4:(ppm) The input should be smaller than 2500.")
            CCl4 = float(sys.stdin.readline())
            if CCl4 < 0 or CCl4 > 2500:
                print("CCl4 concentration out of bound.")
                continue
            out = False
            while(1):
                print("Temperature: please separate the data points by \",\"\n\
ex:350,368,382,400,409,415,421,427,433,440,445,450,453,456,459,462,465,468,471")
                try:
                    lst = list(
                        map(float, sys.stdin.readline().strip().split(",")))
                except(ValueError) as e:
                    print(str(e)+"Please place comma in the right position.")
                    continue
                print(f"len: {len(lst)}")
                if len(lst) == 19 or len(lst) == 23:
                    out = True
                else:
                    print(
                        "Invalid temperature input: length should be 19 or 23!!")
                    out = False
                if not out:
                    continue
                if any(t > 300 and t < 487 for t in lst):
                    out = True
                else:
                    print(
                        "Input range out of bound! Should be within 300 and 487")
                    out = False
                if out:
                    break
            global y_pre
            y_pre = [0]
            n_steps = 100
            n_pfr = len(lst)-1
            l = 18
            mfr /= 3.6
            CCl4 /= 1e6
            add_directory(join(BASE_DIR))
            A = 0.0321263 if n_pfr == 18 else 0.05388554
            reaction_mech = join(
                BASE_DIR, 'chem_annotated_irreversible_aspen.xml')
            # Prediction
            print('Start the prediction...')
            print('cracking rates are:')
            predict(reaction_mech, lst, (p), CCl4, (mfr),
                    n_steps, n_pfr, l, A)
            print("continue?(y/n)")
            pause = True
            while True:
                a = sys.stdin.readline().strip()
                if(a == "y"):
                    pause = False
                    break
                elif(a == "n"):
                    break
                else:
                    print("Invalid input!")

            if (pause):
                system("pause")
                sys.exit()

    except Exception as e:
        print('Unexpected error:' + str(e))
        print("continue?(y/n)")
        pause = True
        while True:
            a = sys.stdin.readline().strip()
            if(a == "y"):
                pause = False
                break
            elif(a == "n"):
                break
            else:
                print("Invalid input!")

        if (pause):
            system("pause")
            sys.exit()
